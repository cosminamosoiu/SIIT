function js_style() {
    document.getElementById('text').style.fontFamily = "Lucida Handwriting";
    document.getElementById('text').style.fontSize = "30px";
    document.getElementById('text').style.color = "red"; 
}