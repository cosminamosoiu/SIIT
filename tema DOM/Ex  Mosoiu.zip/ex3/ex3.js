function colorParagraph() {
    document.getElementById("paragraph").style.backgroundColor = 'red';
}